---
layout: page
title: About
---

<p class="message">
  Hi there! This page is included as an example. Feel free to customize it for your own use upon downloading. Carry on!
</p>

## About BlackDoc Theme

Some relevant information about this project:

* Built for [Jekyll](http://jekyllrb.com)
* Theme based on [Poole](http://getpoole.com), the Jekyll butler, and the [Hyde](http://hyde.getpoole.com) theme
* Ideal for sites requiring master-detail layout such as documentation, cheatsheets, lyrics, notes, etc.
* Need a beautiful color scheme for black background? Then you will love BlackDoc theme.

